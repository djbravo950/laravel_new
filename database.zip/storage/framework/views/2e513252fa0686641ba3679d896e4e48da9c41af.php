

<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div id="page_title">
      <div class="container text-center">
        <div class="panel-heading">Service</div>
        <ol class="breadcrumb text-center">
          <li><a href="#">Home</a></li>
          <li class="active">Service</li>
        </ol>
      </div>
    </div>


    <section id="service_page">
      <div class="container text-center">
        <div class="row">
          <div class="col-md-4 col-sm-6 col-xs-12 srevice_img"><div class="box-shad"><a href="service_detail.html"><img src="<?php echo e(asset('frontend/image/ac-repair.png')); ?>" class="img-circle htw" alt="cleaning"></a>
            <h4><a href="service_detail.html">AC repair</a></h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry.</p></div> 
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 srevice_img active"><div class="box-shad"> <a href="service_detail.html"><img src="<?php echo e(asset('frontend/image/fridge-repair.jpg')); ?>" class="img-circle htw" alt="electrical"></a>
            <h4><a href="service_detail.html">servicing Fridge</a></h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry.</p></div> 
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 srevice_img"><div class="box-shad"><a href="service_detail.html"> <img src="<?php echo e(asset('frontend/image/washing-machine-repair.jpg')); ?>" class="img-circle htw" alt="plumbing"></a>
            <h4><a href="service_detail.html">Washing machine service</a></h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry.</p></div> 
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 srevice_img"><div class="box-shad"> <a href="service_detail.html"><img src="<?php echo e(asset('frontend/image/electrical-service.jpg')); ?>" class="img-circle htw" alt="appliances"></a>
            <h4><a href="service_detail.html">Electrical services</a></h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry.</p></div> 
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 srevice_img"><div class="box-shad"><a href="service_detail.html"> <img src="<?php echo e(asset('frontend/image/salon-home.jpeg')); ?>" class="img-circle htw" alt="carpentry"></a>
            <h4><a href="service_detail.html">Salon at Home</a></h4>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's typesetting industry.</p></div> 
          </div>
        </div>
      </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontlayout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ARIJIT MANNA\Desktop\repairservice\blog\resources\views/service.blade.php ENDPATH**/ ?>