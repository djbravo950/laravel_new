
<div class="row">
    <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12">
        <h5>address:<?php echo e($p->address); ?></h5>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\Users\ARIJIT MANNA\Desktop\repairservice\blog\resources\views/profile.blade.php ENDPATH**/ ?>